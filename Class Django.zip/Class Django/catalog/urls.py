from django.urls import path
from .views import finalProject

urlpatterns = [
    path('', finalProject)
]

